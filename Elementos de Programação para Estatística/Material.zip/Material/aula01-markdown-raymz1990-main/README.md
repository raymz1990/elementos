# Aula 01: Markdown

## Formatação de Texto

1.  Crie um título de nível 1.

2.  Escreva um parágrafo de texto normal.

3.  Destaque uma palavra em itálico.

4.  Deixe outra palavra em negrito.
28. Crie um texto com sublinhado.

6.  Combine itálico e negrito em uma mesma palavra.

7.  Crie uma lista não ordenada com três itens.

8.  Faça uma lista ordenada com quatro itens.

9.  Crie um link para o site do Google.

10.  Insira uma imagem que esteja no mesmo diretório que seu arquivo.

11. Insira uma imagem da internet.

10. Crie um bloco de citação.

## Elementos Estruturais

11. Crie um sub-título de nível 2.

12. Faça uma divisão horizontal.

13. Crie uma lista aninhada com pelo menos dois níveis.

14. Crie um trecho de código inline.

15. Insira um bloco de código com realce de sintaxe para R.

16. Crie um link para uma seção dentro do próprio documento.

17. Liste os itens a seguir em uma tabela com duas colunas: "Item" e "Quantidade".

    -   Maçãs, 5

    -   Bananas, 3

    -   Laranjas, 8

## Outras Funcionalidades

18. Crie uma nota de rodapé com uma explicação.

19. Crie uma lista de tarefas com três itens.

20. Inclua uma citação de um livro ou autor.

21. Crie um bloco de código com várias linhas usando realce de sintaxe.

22. Destaque um trecho de texto como código, sem realce de sintaxe.

23. Crie um link automático para um URL.

25. Liste os passos de um tutorial usando sub-listas.

26. Incorpore um vídeo do YouTube.

27. Insira um elemento de áudio.

29. Insira um emoji no seu texto (por exemplo, um coração ♥).

30. Crie um alerta colorido usando _callout_.
